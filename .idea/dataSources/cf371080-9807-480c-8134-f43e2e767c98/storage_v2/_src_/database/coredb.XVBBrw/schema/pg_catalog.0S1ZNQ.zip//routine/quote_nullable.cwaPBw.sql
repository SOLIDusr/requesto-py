create function quote_nullable(anyelement) returns text
    stable
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.quote_nullable($1::pg_catalog.text)$$;

comment on function quote_nullable(anyelement) is 'quote a possibly-null data value for usage in a querystring';

alter function quote_nullable(anyelement) owner to dolta;

